import { useState } from 'react';
import { AuthProvider, useAuth } from './hooks/useAuth.jsx';
import Layout from './components/Layout';
import LoginForm from './components/LoginForm';
import Dashboard from './components/Dashboard';
import './App.css';

// Placeholder components for different pages
const CalendarPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Calendar</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Calendar functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include appointment scheduling, calendar views (daily, weekly, monthly), 
        and color-coded client appointments.
      </p>
    </div>
  </div>
);

const PatientsPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Patients</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Patient management functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include adding/editing patients, viewing patient details, 
        and managing patient-client relationships.
      </p>
    </div>
  </div>
);

const ClientsPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Clients</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Client management functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include adding/editing clients, assigning color codes, 
        and managing client organizations.
      </p>
    </div>
  </div>
);

const RoutesPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Routes</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Route optimization functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include route generation, map views, text list views, 
        and visit note management.
      </p>
    </div>
  </div>
);

const MessagesPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Communication functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include SMS messaging, call initiation, message templates, 
        and communication logs.
      </p>
    </div>
  </div>
);

const NotesPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">Notes</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">Notes functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include visit documentation, note templates, 
        and PDF export capabilities.
      </p>
    </div>
  </div>
);

const UsersPage = () => (
  <div className="space-y-6">
    <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
    <div className="bg-white p-6 rounded-lg shadow">
      <p className="text-gray-600">User management functionality will be implemented here.</p>
      <p className="text-sm text-gray-500 mt-2">
        This will include adding/editing users, role assignment, 
        and user permissions management.
      </p>
    </div>
  </div>
);

// Main App Content Component
const AppContent = () => {
  const { isAuthenticated, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginForm />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentPage} />;
      case 'calendar':
        return <CalendarPage />;
      case 'patients':
        return <PatientsPage />;
      case 'clients':
        return <ClientsPage />;
      case 'routes':
        return <RoutesPage />;
      case 'messages':
        return <MessagesPage />;
      case 'notes':
        return <NotesPage />;
      case 'users':
        return <UsersPage />;
      default:
        return <Dashboard onNavigate={setCurrentPage} />;
    }
  };

  return (
    <Layout currentPage={currentPage} onNavigate={setCurrentPage}>
      {renderPage()}
    </Layout>
  );
};

// Main App Component
function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;

