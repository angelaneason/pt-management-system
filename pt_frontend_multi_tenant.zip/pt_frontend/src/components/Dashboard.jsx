import { useState, useEffect } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import { appointmentsAPI, routesAPI } from '../lib/api';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Calendar, Users, Route, MessageSquare, Clock, CheckCircle } from 'lucide-react';

const Dashboard = ({ onNavigate }) => {
  const { user, isClinician, isAdmin } = useAuth();
  const [stats, setStats] = useState({
    todayAppointments: 0,
    upcomingAppointments: 0,
    activeRoutes: 0,
    completedVisits: 0,
  });
  const [todayAppointments, setTodayAppointments] = useState([]);
  const [todayRoute, setTodayRoute] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, [user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      
      // Get today's date range
      const today = new Date();
      const startOfDay = new Date(today.setHours(0, 0, 0, 0)).toISOString();
      const endOfDay = new Date(today.setHours(23, 59, 59, 999)).toISOString();

      // Load appointments
      const appointmentsParams = {
        start_date: startOfDay,
        end_date: endOfDay,
      };
      
      if (isClinician) {
        appointmentsParams.clinician_id = user.id;
      }

      const appointments = await appointmentsAPI.getAppointments(appointmentsParams);
      setTodayAppointments(appointments);

      // Load route data for clinicians
      if (isClinician) {
        try {
          const route = await routesAPI.getTodayRoutes();
          setTodayRoute(route);
        } catch (err) {
          // No route for today is okay
          setTodayRoute(null);
        }
      }

      // Calculate stats
      const completedToday = appointments.filter(apt => apt.status === 'completed').length;
      
      setStats({
        todayAppointments: appointments.length,
        upcomingAppointments: appointments.filter(apt => apt.status === 'scheduled').length,
        activeRoutes: todayRoute ? 1 : 0,
        completedVisits: completedToday,
      });

    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (dateString) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    });
  };

  const quickActions = [
    {
      title: 'View Calendar',
      description: 'Manage appointments and schedules',
      icon: Calendar,
      action: () => onNavigate('calendar'),
      show: true,
    },
    {
      title: 'Manage Patients',
      description: 'Add or update patient information',
      icon: Users,
      action: () => onNavigate('patients'),
      show: true,
    },
    {
      title: 'View Routes',
      description: 'Optimize and manage visit routes',
      icon: Route,
      action: () => onNavigate('routes'),
      show: true,
    },
    {
      title: 'Send Messages',
      description: 'Communicate with patients and staff',
      icon: MessageSquare,
      action: () => onNavigate('messages'),
      show: isAdmin,
    },
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                <div className="h-8 bg-gray-200 rounded w-1/2"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-1">
          Welcome back, {user?.username}! Here's what's happening today.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Today's Appointments</p>
                <p className="text-3xl font-bold text-gray-900">{stats.todayAppointments}</p>
              </div>
              <Calendar className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Upcoming</p>
                <p className="text-3xl font-bold text-gray-900">{stats.upcomingAppointments}</p>
              </div>
              <Clock className="h-8 w-8 text-yellow-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Completed Visits</p>
                <p className="text-3xl font-bold text-gray-900">{stats.completedVisits}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Routes</p>
                <p className="text-3xl font-bold text-gray-900">{stats.activeRoutes}</p>
              </div>
              <Route className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Appointments */}
        <Card>
          <CardHeader>
            <CardTitle>Today's Appointments</CardTitle>
            <CardDescription>
              Your scheduled appointments for today
            </CardDescription>
          </CardHeader>
          <CardContent>
            {todayAppointments.length === 0 ? (
              <p className="text-gray-500 text-center py-4">
                No appointments scheduled for today
              </p>
            ) : (
              <div className="space-y-3">
                {todayAppointments.slice(0, 5).map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-gray-900">
                        {appointment.patient_name}
                      </p>
                      <p className="text-sm text-gray-600">
                        {formatTime(appointment.start_time)} - {formatTime(appointment.end_time)}
                      </p>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded-full ${
                      appointment.status === 'completed'
                        ? 'bg-green-100 text-green-800'
                        : appointment.status === 'scheduled'
                        ? 'bg-blue-100 text-blue-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {appointment.status}
                    </span>
                  </div>
                ))}
                {todayAppointments.length > 5 && (
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => onNavigate('calendar')}
                  >
                    View All Appointments
                  </Button>
                )}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>
              Common tasks and shortcuts
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 gap-3">
              {quickActions
                .filter(action => action.show)
                .map((action, index) => {
                  const Icon = action.icon;
                  return (
                    <Button
                      key={index}
                      variant="outline"
                      className="justify-start h-auto p-4"
                      onClick={action.action}
                    >
                      <Icon className="h-5 w-5 mr-3" />
                      <div className="text-left">
                        <p className="font-medium">{action.title}</p>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                    </Button>
                  );
                })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;

