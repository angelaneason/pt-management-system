import { useState } from 'react';
import { useAuth } from '../hooks/useAuth.jsx';
import CompanySelector from './CompanySelector.jsx';
import { Button } from '@/components/ui/button';
import { 
  Calendar, 
  Users, 
  UserPlus, 
  MessageSquare, 
  Route, 
  FileText, 
  Settings, 
  LogOut,
  Menu,
  X,
  BarChart3,
  Shield,
  Building2,
  CreditCard,
  UserCog
} from 'lucide-react';

const Layout = ({ children, currentPage, onNavigate }) => {
  const { 
    user, 
    logout, 
    currentCompany, 
    currentRole,
    isAdmin,
    isPracticeManager,
    isClinician,
    canManageUsers,
    canManageSettings,
    canViewReports,
    canManageBilling
  } = useAuth();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const navigationItems = [
    { 
      id: 'dashboard', 
      label: 'Dashboard', 
      icon: Calendar, 
      show: true,
      description: 'Overview and quick actions'
    },
    { 
      id: 'calendar', 
      label: 'Calendar', 
      icon: Calendar, 
      show: true,
      description: 'Appointment scheduling'
    },
    { 
      id: 'patients', 
      label: 'Patients', 
      icon: Users, 
      show: true,
      description: 'Patient management'
    },
    { 
      id: 'clients', 
      label: 'Clients', 
      icon: UserPlus, 
      show: true,
      description: 'Client organizations'
    },
    { 
      id: 'routes', 
      label: 'Routes', 
      icon: Route, 
      show: true,
      description: 'Home visit routing'
    },
    { 
      id: 'messages', 
      label: 'Messages', 
      icon: MessageSquare, 
      show: true,
      description: 'Communication hub'
    },
    { 
      id: 'notes', 
      label: 'Notes', 
      icon: FileText, 
      show: true,
      description: 'Visit documentation'
    },
    { 
      id: 'reports', 
      label: 'Reports', 
      icon: BarChart3, 
      show: canViewReports,
      description: 'Analytics and insights'
    },
    { 
      id: 'billing', 
      label: 'Billing', 
      icon: CreditCard, 
      show: canManageBilling,
      description: 'Financial management'
    },
    { 
      id: 'users', 
      label: 'User Management', 
      icon: UserCog, 
      show: canManageUsers,
      description: 'Staff and permissions'
    },
    { 
      id: 'settings', 
      label: 'Settings', 
      icon: Settings, 
      show: canManageSettings,
      description: 'System configuration'
    },
  ];

  const handleLogout = async () => {
    await logout();
  };

  const handleNavigation = (pageId) => {
    onNavigate(pageId);
    setSidebarOpen(false);
  };

  const getRoleColor = (role) => {
    const roleColors = {
      'Super Admin': 'text-purple-600 bg-purple-100',
      'Company Admin': 'text-blue-600 bg-blue-100',
      'Practice Manager': 'text-green-600 bg-green-100',
      'Clinician': 'text-orange-600 bg-orange-100',
      'Office Staff': 'text-gray-600 bg-gray-100',
      'Scheduler': 'text-indigo-600 bg-indigo-100'
    };
    return roleColors[role] || 'text-gray-600 bg-gray-100';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Mobile menu button */}
      <div className="lg:hidden fixed top-4 left-4 z-50">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setSidebarOpen(!sidebarOpen)}
        >
          {sidebarOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
        </Button>
      </div>

      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-40 w-80 bg-white shadow-lg transform transition-transform duration-300 ease-in-out ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } lg:translate-x-0`}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 border-b bg-gradient-to-r from-blue-600 to-blue-700 text-white">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-10 h-10 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
                <Building2 className="w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-bold">PT Management</h1>
                <p className="text-blue-100 text-sm">Multi-Tenant System</p>
              </div>
            </div>
            
            {/* User Info */}
            <div className="bg-white bg-opacity-10 rounded-lg p-3">
              <div className="flex items-center justify-between mb-2">
                <p className="text-sm font-medium">
                  {user?.full_name || user?.username}
                </p>
                {currentRole && (
                  <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white bg-opacity-20 text-white`}>
                    {currentRole}
                  </span>
                )}
              </div>
              <p className="text-xs text-blue-100">{user?.email}</p>
            </div>
          </div>

          {/* Company Selector */}
          <div className="p-4 border-b bg-gray-50">
            <CompanySelector />
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
            {navigationItems
              .filter(item => item.show)
              .map((item) => {
                const Icon = item.icon;
                const isActive = currentPage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavigation(item.id)}
                    className={`w-full flex items-center px-4 py-3 text-left rounded-lg transition-all duration-200 group ${
                      isActive
                        ? 'bg-blue-100 text-blue-700 border border-blue-200 shadow-sm'
                        : 'text-gray-700 hover:bg-gray-100 hover:text-gray-900'
                    }`}
                  >
                    <Icon className={`h-5 w-5 mr-3 transition-colors ${
                      isActive ? 'text-blue-600' : 'text-gray-500 group-hover:text-gray-700'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.label}</p>
                      <p className={`text-xs truncate ${
                        isActive ? 'text-blue-600' : 'text-gray-500'
                      }`}>
                        {item.description}
                      </p>
                    </div>
                  </button>
                );
              })}
          </nav>

          {/* Company Info */}
          {currentCompany && (
            <div className="p-4 border-t bg-gray-50">
              <div className="text-xs text-gray-500 mb-1">Current Company</div>
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-4 h-4 text-blue-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {currentCompany.name}
                  </p>
                  <p className="text-xs text-gray-500 truncate">
                    {currentCompany.slug}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Footer */}
          <div className="p-4 border-t">
            <Button
              variant="outline"
              className="w-full"
              onClick={handleLogout}
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </div>

      {/* Overlay for mobile */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black bg-opacity-50 z-30 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Main content */}
      <div className="lg:ml-80">
        {/* Top bar for mobile */}
        <div className="lg:hidden bg-white border-b px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                <Building2 className="w-4 h-4 text-blue-600" />
              </div>
              <div>
                <p className="text-sm font-medium text-gray-900">
                  {currentCompany?.name || 'PT Management'}
                </p>
                <p className="text-xs text-gray-500">
                  {currentRole}
                </p>
              </div>
            </div>
          </div>
        </div>

        <main className="p-6">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 capitalize">
                  {currentPage === 'dashboard' ? 'Dashboard' : currentPage}
                </h2>
                <p className="text-gray-600 text-sm mt-1">
                  {navigationItems.find(item => item.id === currentPage)?.description || 'Manage your physical therapy practice'}
                </p>
              </div>
              
              {/* Company context indicator */}
              {currentCompany && (
                <div className="hidden lg:flex items-center space-x-2 text-sm text-gray-500">
                  <Building2 className="w-4 h-4" />
                  <span>{currentCompany.name}</span>
                  <span className="text-gray-300">•</span>
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getRoleColor(currentRole)}`}>
                    {currentRole}
                  </span>
                </div>
              )}
            </div>
          </div>

          {children}
        </main>
      </div>
    </div>
  );
};

export default Layout;

