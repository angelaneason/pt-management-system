import React, { useState } from 'react';
import { useAuth, useCompanySelector } from '../hooks/useAuth';
import { Building2, ChevronDown, Check, Plus, Settings } from 'lucide-react';

const CompanySelector = ({ className = '' }) => {
  const { user, currentCompany, currentRole, switchCompany, createCompany } = useAuth();
  const { companies, hasMultipleCompanies } = useCompanySelector();
  const [isOpen, setIsOpen] = useState(false);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [newCompanyData, setNewCompanyData] = useState({
    name: '',
    description: '',
    email: '',
    phone: '',
    address: ''
  });

  const handleCompanySwitch = async (companySlug) => {
    if (companySlug === currentCompany?.slug) {
      setIsOpen(false);
      return;
    }

    try {
      setLoading(true);
      await switchCompany(companySlug);
      setIsOpen(false);
      // Refresh the page to update all components with new tenant context
      window.location.reload();
    } catch (error) {
      console.error('Error switching company:', error);
      alert('Failed to switch company. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCompany = async (e) => {
    e.preventDefault();
    
    if (!newCompanyData.name.trim()) {
      alert('Company name is required');
      return;
    }

    try {
      setLoading(true);
      await createCompany(newCompanyData);
      setShowCreateForm(false);
      setNewCompanyData({
        name: '',
        description: '',
        email: '',
        phone: '',
        address: ''
      });
      alert('Company created successfully!');
    } catch (error) {
      console.error('Error creating company:', error);
      alert('Failed to create company. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const getRoleColor = (role) => {
    const roleColors = {
      'Super Admin': 'text-purple-600 bg-purple-100',
      'Company Admin': 'text-blue-600 bg-blue-100',
      'Practice Manager': 'text-green-600 bg-green-100',
      'Clinician': 'text-orange-600 bg-orange-100',
      'Office Staff': 'text-gray-600 bg-gray-100',
      'Scheduler': 'text-indigo-600 bg-indigo-100'
    };
    return roleColors[role] || 'text-gray-600 bg-gray-100';
  };

  if (!currentCompany) {
    return null;
  }

  return (
    <div className={`relative ${className}`}>
      {/* Company Selector Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center space-x-3 w-full p-3 text-left bg-white border border-gray-200 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-colors"
        disabled={loading}
      >
        <div className="flex-shrink-0">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Building2 className="w-5 h-5 text-blue-600" />
          </div>
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <p className="text-sm font-medium text-gray-900 truncate">
              {currentCompany.name}
            </p>
            {currentRole && (
              <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getRoleColor(currentRole)}`}>
                {currentRole}
              </span>
            )}
          </div>
          <p className="text-xs text-gray-500 truncate">
            {companies.length} {companies.length === 1 ? 'company' : 'companies'} available
          </p>
        </div>
        
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50 max-h-96 overflow-y-auto">
          {/* Current User Info */}
          <div className="p-3 border-b border-gray-100">
            <p className="text-sm font-medium text-gray-900">{user?.full_name || user?.username}</p>
            <p className="text-xs text-gray-500">{user?.email}</p>
          </div>

          {/* Companies List */}
          <div className="py-1">
            {companies.map((company) => (
              <button
                key={company.id}
                onClick={() => handleCompanySwitch(company.slug)}
                className="w-full px-3 py-2 text-left hover:bg-gray-50 focus:outline-none focus:bg-gray-50 transition-colors"
                disabled={loading}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center space-x-2">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {company.name}
                      </p>
                      {company.slug === currentCompany?.slug && (
                        <Check className="w-4 h-4 text-blue-600" />
                      )}
                    </div>
                    <div className="flex items-center space-x-2 mt-1">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${getRoleColor(company.role)}`}>
                        {company.role}
                      </span>
                      {company.last_access && (
                        <span className="text-xs text-gray-500">
                          Last accessed: {new Date(company.last_access).toLocaleDateString()}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Actions */}
          <div className="border-t border-gray-100 py-1">
            <button
              onClick={() => setShowCreateForm(true)}
              className="w-full px-3 py-2 text-left text-sm text-blue-600 hover:bg-blue-50 focus:outline-none focus:bg-blue-50 transition-colors flex items-center space-x-2"
            >
              <Plus className="w-4 h-4" />
              <span>Create New Company</span>
            </button>
            
            <button
              onClick={() => {
                setIsOpen(false);
                // Navigate to company settings
                window.location.href = '/settings/company';
              }}
              className="w-full px-3 py-2 text-left text-sm text-gray-600 hover:bg-gray-50 focus:outline-none focus:bg-gray-50 transition-colors flex items-center space-x-2"
            >
              <Settings className="w-4 h-4" />
              <span>Company Settings</span>
            </button>
          </div>
        </div>
      )}

      {/* Create Company Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h3 className="text-lg font-medium text-gray-900 mb-4">Create New Company</h3>
              
              <form onSubmit={handleCreateCompany} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Company Name *
                  </label>
                  <input
                    type="text"
                    value={newCompanyData.name}
                    onChange={(e) => setNewCompanyData({ ...newCompanyData, name: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter company name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    value={newCompanyData.description}
                    onChange={(e) => setNewCompanyData({ ...newCompanyData, description: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Brief description of the company"
                    rows={3}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email
                  </label>
                  <input
                    type="email"
                    value={newCompanyData.email}
                    onChange={(e) => setNewCompanyData({ ...newCompanyData, email: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="company@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={newCompanyData.phone}
                    onChange={(e) => setNewCompanyData({ ...newCompanyData, phone: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="+1 (555) 123-4567"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Address
                  </label>
                  <textarea
                    value={newCompanyData.address}
                    onChange={(e) => setNewCompanyData({ ...newCompanyData, address: e.target.value })}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Company address"
                    rows={2}
                  />
                </div>

                <div className="flex space-x-3 pt-4">
                  <button
                    type="submit"
                    disabled={loading}
                    className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                  >
                    {loading ? 'Creating...' : 'Create Company'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Loading Overlay */}
      {loading && (
        <div className="absolute inset-0 bg-white bg-opacity-75 flex items-center justify-center rounded-lg">
          <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
        </div>
      )}
    </div>
  );
};

export default CompanySelector;

