import { useState, useEffect, createContext, useContext } from 'react';
import { authAPI, setAuthToken, setCurrentTenant, clearAuth, getCurrentTenant, getCurrentCompany } from '../lib/api';

// Create Auth Context
const AuthContext = createContext();

// Auth Provider Component
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [currentCompany, setCurrentCompanyState] = useState(null);
  const [companies, setCompanies] = useState([]);
  const [currentRole, setCurrentRole] = useState(null);
  const [permissions, setPermissions] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Check if user is logged in on app start
  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = async () => {
    try {
      setLoading(true);
      
      // Check if we have stored auth data
      const storedUser = localStorage.getItem('user');
      const storedCompanies = localStorage.getItem('companies');
      const storedCompany = getCurrentCompany();
      const authToken = localStorage.getItem('authToken');
      
      if (storedUser && storedCompanies && storedCompany && authToken) {
        setUser(JSON.parse(storedUser));
        setCompanies(JSON.parse(storedCompanies));
        setCurrentCompanyState(storedCompany);
        
        // Find current role and permissions
        const companiesData = JSON.parse(storedCompanies);
        const currentCompanyData = companiesData.find(c => c.slug === storedCompany.slug);
        if (currentCompanyData) {
          setCurrentRole(currentCompanyData.role);
          setPermissions(currentCompanyData.permissions || {});
        }
        
        // Verify token is still valid
        try {
          await authAPI.getUserCompanies();
        } catch (err) {
          // Token is invalid, clear auth
          handleLogout();
        }
      } else {
        setUser(null);
        setCurrentCompanyState(null);
        setCompanies([]);
        setCurrentRole(null);
        setPermissions({});
      }
    } catch (err) {
      console.error('Auth status check error:', err);
      setUser(null);
      setCurrentCompanyState(null);
      setCompanies([]);
      setCurrentRole(null);
      setPermissions({});
    } finally {
      setLoading(false);
    }
  };

  const login = async (credentials) => {
    try {
      setError(null);
      setLoading(true);
      
      const response = await authAPI.login(credentials);
      
      setUser(response.user);
      setCurrentCompanyState(response.current_company);
      setCompanies(response.companies);
      setCurrentRole(response.current_role);
      setPermissions(response.permissions || {});
      
      return response;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const register = async (userData) => {
    try {
      setError(null);
      setLoading(true);
      
      const response = await authAPI.register(userData);
      
      // Registration doesn't automatically log in, user needs to login
      return response;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const switchCompany = async (companySlug) => {
    try {
      setError(null);
      setLoading(true);
      
      const response = await authAPI.switchCompany(companySlug);
      
      setCurrentCompanyState(response.current_company);
      setCurrentRole(response.current_role);
      setPermissions(response.permissions || {});
      
      // Update companies list with new access time
      const updatedCompanies = companies.map(company => 
        company.slug === companySlug 
          ? { ...company, is_current: true, last_access: new Date().toISOString() }
          : { ...company, is_current: false }
      );
      setCompanies(updatedCompanies);
      localStorage.setItem('companies', JSON.stringify(updatedCompanies));
      
      return response;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const createCompany = async (companyData) => {
    try {
      setError(null);
      setLoading(true);
      
      const response = await authAPI.createCompany(companyData);
      
      // Refresh companies list
      const companiesResponse = await authAPI.getUserCompanies();
      setCompanies(companiesResponse.companies);
      localStorage.setItem('companies', JSON.stringify(companiesResponse.companies));
      
      return response;
    } catch (err) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const refreshCompanies = async () => {
    try {
      const response = await authAPI.getUserCompanies();
      setCompanies(response.companies);
      localStorage.setItem('companies', JSON.stringify(response.companies));
      return response.companies;
    } catch (err) {
      console.error('Error refreshing companies:', err);
      throw err;
    }
  };

  const handleLogout = () => {
    clearAuth();
    setUser(null);
    setCurrentCompanyState(null);
    setCompanies([]);
    setCurrentRole(null);
    setPermissions({});
  };

  const logout = async () => {
    try {
      await authAPI.logout();
    } catch (err) {
      console.error('Logout error:', err);
    } finally {
      handleLogout();
    }
  };

  // Permission checking functions
  const hasPermission = (permission) => {
    if (!permissions) return false;
    return permissions[permission] === true;
  };

  const hasRole = (role) => {
    if (Array.isArray(role)) {
      return role.includes(currentRole);
    }
    return currentRole === role;
  };

  const isAdmin = () => {
    return hasRole(['Super Admin', 'Company Admin']);
  };

  const isPracticeManager = () => {
    return hasRole(['Super Admin', 'Company Admin', 'Practice Manager']);
  };

  const isClinician = () => {
    return hasRole(['Clinician', 'Physical Therapist', 'PT', 'Occupational Therapist', 'OT']);
  };

  const isOfficeStaff = () => {
    return hasRole(['Office Staff', 'Scheduler']);
  };

  const canManageUsers = () => {
    return isAdmin() || hasPermission('manage_users');
  };

  const canManageSettings = () => {
    return isAdmin() || hasPermission('manage_settings');
  };

  const canViewReports = () => {
    return isPracticeManager() || hasPermission('view_reports');
  };

  const canManageBilling = () => {
    return isAdmin() || hasPermission('manage_billing');
  };

  const value = {
    // User and authentication state
    user,
    loading,
    error,
    isAuthenticated: !!user,
    
    // Company and tenant state
    currentCompany,
    companies,
    currentRole,
    permissions,
    currentTenant: getCurrentTenant(),
    
    // Authentication actions
    login,
    register,
    logout,
    
    // Company management actions
    switchCompany,
    createCompany,
    refreshCompanies,
    
    // Permission checking functions
    hasPermission,
    hasRole,
    isAdmin,
    isPracticeManager,
    isClinician,
    isOfficeStaff,
    canManageUsers,
    canManageSettings,
    canViewReports,
    canManageBilling,
    
    // Legacy role checks for backward compatibility
    isAdminLegacy: isAdmin(),
    isClinicianLegacy: isClinician(),
    isOfficeStaffLegacy: isOfficeStaff(),
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};

// Custom hook to use auth context
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

// Higher-order component for protecting routes
export const withAuth = (WrappedComponent, requiredPermissions = []) => {
  return function AuthenticatedComponent(props) {
    const { isAuthenticated, hasPermission, loading } = useAuth();
    
    if (loading) {
      return <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-600"></div>
      </div>;
    }
    
    if (!isAuthenticated) {
      window.location.href = '/login';
      return null;
    }
    
    // Check required permissions
    if (requiredPermissions.length > 0) {
      const hasRequiredPermissions = requiredPermissions.every(permission => hasPermission(permission));
      if (!hasRequiredPermissions) {
        return <div className="flex items-center justify-center min-h-screen">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
            <p className="text-gray-600">You don't have permission to access this page.</p>
          </div>
        </div>;
      }
    }
    
    return <WrappedComponent {...props} />;
  };
};

// Hook for company selection
export const useCompanySelector = () => {
  const { companies, currentCompany, switchCompany, loading } = useAuth();
  
  return {
    companies,
    currentCompany,
    switchCompany,
    loading,
    hasMultipleCompanies: companies.length > 1,
  };
};

